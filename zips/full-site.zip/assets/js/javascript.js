"use strict";

window.onload = function () {
  AOS.init();

  MediaBox('.mediabox');
};
